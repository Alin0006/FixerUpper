-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 02, 2025 at 11:36 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `fixerupper_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `status` enum('active','inactive') DEFAULT 'active',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `contact_messages`
--

CREATE TABLE `contact_messages` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `subject` varchar(200) NOT NULL,
  `message` text NOT NULL,
  `status` enum('new','read','replied') DEFAULT 'new',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `total_amount` decimal(10,2) NOT NULL,
  `shipping_cost` decimal(10,2) DEFAULT 0.00,
  `delivery_method` enum('home_delivery','store_collection') NOT NULL,
  `payment_method` enum('card','paypal','bank_transfer') NOT NULL,
  `billing_address` text NOT NULL,
  `delivery_address` text DEFAULT NULL,
  `special_instructions` text DEFAULT NULL,
  `status` enum('pending','processing','shipped','delivered','cancelled') DEFAULT 'pending',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `user_id`, `total_amount`, `shipping_cost`, `delivery_method`, `payment_method`, `billing_address`, `delivery_address`, `special_instructions`, `status`, `created_at`, `updated_at`) VALUES
(1, 1, 780.00, 0.00, 'home_delivery', 'card', 'Leeds', '', '', 'pending', '2025-07-02 16:08:05', '2025-07-02 16:08:05');

-- --------------------------------------------------------

--
-- Table structure for table `order_items`
--

CREATE TABLE `order_items` (
  `id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `price` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `order_items`
--

INSERT INTO `order_items` (`id`, `order_id`, `product_id`, `quantity`, `price`) VALUES
(1, 1, 251, 1, 780.00);

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `name` varchar(200) NOT NULL,
  `description` text DEFAULT NULL,
  `category` varchar(100) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `stock_quantity` int(11) DEFAULT 0,
  `image` varchar(255) DEFAULT 'images/default-product.jpg',
  `status` enum('active','inactive') DEFAULT 'active',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `name`, `description`, `category`, `price`, `stock_quantity`, `image`, `status`, `created_at`, `updated_at`) VALUES
(241, 'Allen Keys', 'Allen wrench set in various sizes for hexagonal socket screws.', 'tools', 35.99, 850, 'images/products/product_686428bebab22.png', 'active', '2025-07-01 18:28:14', '2025-07-01 18:28:14'),
(242, 'Hammer', 'construction hammer with metal head and ergonomic wooden handle.', 'tools', 49.99, 325, 'images/products/product_686428f4974a5.jpg', 'active', '2025-07-01 18:29:08', '2025-07-01 18:29:08'),
(244, 'Saw', 'Woodworking saw with red handle and toothed blade for cutting wood.', 'tools', 44.99, 85, 'images/products/product_6864295916c92.jpg', 'active', '2025-07-01 18:30:49', '2025-07-01 18:30:49'),
(245, 'Toolbox', 'Wooden toolbox', 'tools', 35.99, 320, 'images/products/product_68642a11316f0.jpg', 'active', '2025-07-01 18:33:53', '2025-07-01 18:33:53'),
(246, 'Drill', 'Battery-powered drill with orange battery pack and chuck for drilling and driving screws.', 'tools', 79.99, 120, 'images/products/product_68642a1a3f584.png', 'active', '2025-07-01 18:34:02', '2025-07-01 18:34:02'),
(247, 'Refrigerator', 'Compact single door refrigerator with freezer compartment. Energy efficient design perfect for small kitchens, apartments, or office spaces. Features adjustable shelves, vegetable crisper drawer, and quiet operation', 'appliances', 399.99, 25, 'images/products/product_68642ee0a38ae.png', 'active', '2025-07-01 18:54:24', '2025-07-01 18:54:24'),
(248, 'Refrigerator', 'Spacious double door refrigerator with separate freezer and fresh food compartments. Large capacity design ideal for families. Includes multiple adjustable shelves, humidity-controlled crisper drawers, door storage bins, and energy-saving technology.', 'appliances', 699.99, 10, 'images/products/product_68642f0ca6064.png', 'active', '2025-07-01 18:55:08', '2025-07-01 18:55:08'),
(249, 'Refrigerator', 'Spacious double door refrigerator with separate freezer and fresh food compartments. Large capacity design ideal for families. Includes multiple adjustable shelves, humidity-controlled crisper drawers, door storage bins, and energy-saving technology.', 'appliances', 699.99, 10, 'images/products/product_686557458f47b.png', 'active', '2025-07-02 15:59:01', '2025-07-02 15:59:01'),
(250, 'Washing Machine', 'Front Load Washing Machine:\r\nHigh-efficiency front loading washing machine with large capacity drum and advanced wash cycles. Features energy-saving technology, multiple wash programs for different fabric types, digital display with timer, and quiet operation. Perfect for modern homes with space-saving stackable design.RetryClaude can make mistakes. Please double-check responses.', 'appliances', 489.99, 12, 'images/products/product_686558020db31.jpg', 'active', '2025-07-02 16:02:10', '2025-07-02 16:02:10'),
(251, 'Air Conditioner', 'Smart - Control from your phone or home assistant. Smart scheduling saves energy\r\nLow Energy - A+++/A++ rated energy efficient cooling &amp; heating all year round\r\nSleep mode sets fan to quietest speed and automatically regulates temperature through the night to save energy and keep you comfortable', 'appliances', 780.00, 5, 'images/products/product_686558c961ee9.png', 'active', '2025-07-02 16:05:29', '2025-07-02 16:08:05');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `first_name` varchar(50) NOT NULL,
  `last_name` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `role` enum('customer','admin') DEFAULT 'customer',
  `status` enum('active','inactive') DEFAULT 'active',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `last_login` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `first_name`, `last_name`, `email`, `password`, `phone`, `address`, `role`, `status`, `created_at`, `last_login`) VALUES
(1, 'Alin', 'Dragomir', 'alin1@gmail.com', '$2y$10$DIRCC3/XgWj9TPe.6FkuFOZWbhLTpKimjUmWmw3xzvfJMY/Ly0xCu', '1234', 'Leeds', 'customer', 'active', '2025-07-02 16:07:20', '2025-07-02 16:07:31');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `contact_messages`
--
ALTER TABLE `contact_messages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `order_items`
--
ALTER TABLE `order_items`
  ADD PRIMARY KEY (`id`),
  ADD KEY `order_id` (`order_id`),
  ADD KEY `product_id` (`product_id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `contact_messages`
--
ALTER TABLE `contact_messages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `order_items`
--
ALTER TABLE `order_items`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=252;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `orders_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `order_items`
--
ALTER TABLE `order_items`
  ADD CONSTRAINT `order_items_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`),
  ADD CONSTRAINT `order_items_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
