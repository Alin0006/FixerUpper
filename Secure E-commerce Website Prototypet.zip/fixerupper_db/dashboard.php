<?php
session_start();
require_once 'config.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$user_name = $_SESSION['user_name'];

$orders_query = "SELECT o.*, COUNT(oi.id) as item_count 
                FROM orders o 
                LEFT JOIN order_items oi ON o.id = oi.order_id 
                WHERE o.user_id = $user_id 
                GROUP BY o.id 
                ORDER BY o.created_at DESC 
                LIMIT 5";
$orders_result = mysqli_query($conn, $orders_query);

$total_orders_query = "SELECT COUNT(*) as total FROM orders WHERE user_id = $user_id";
$total_orders_result = mysqli_query($conn, $total_orders_query);
$total_orders = mysqli_fetch_assoc($total_orders_result)['total'];

$total_spent_query = "SELECT SUM(total_amount) as total FROM orders WHERE user_id = $user_id AND status != 'cancelled'";
$total_spent_result = mysqli_query($conn, $total_spent_query);
$total_spent = mysqli_fetch_assoc($total_spent_result)['total'] ?? 0;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - FixerUpper</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <header>
        <nav class="navbar">
            <div class="nav-container">
                <div class="nav-logo">
                    <h2><a href="index.php">FixerUpper</a></h2>
                </div>
                <div class="nav-menu">
                    <a href="index.php">Home</a>
                    <a href="products.php">Products</a>
                    <a href="cart.php">Cart</a>
                    <a href="dashboard.php" class="active">Dashboard</a>
                    <a href="logout.php">Logout</a>
                </div>
            </div>
        </nav>
    </header>

    <main>
        <div class="dashboard-container">
            <div class="dashboard-header">
                <h1>Welcome back, <?php echo htmlspecialchars($user_name); ?>!</h1>
            </div>

            <div class="dashboard-stats">
                <div class="stat-card">
                    <h3>Total Orders</h3>
                    <p class="stat-number"><?php echo $total_orders; ?></p>
                </div>
                <div class="stat-card">
                    <h3>Total Spent</h3>
                    <p class="stat-number">£<?php echo number_format($total_spent, 2); ?></p>
                </div>
                <div class="stat-card">
                    <h3>Cart Items</h3>
                    <p class="stat-number"><?php echo isset($_SESSION['cart']) ? count($_SESSION['cart']) : 0; ?></p>
                </div>
            </div>

            <div class="dashboard-content">
                <div class="dashboard-section">
                    <h2>Recent Orders</h2>
                    <?php if (mysqli_num_rows($orders_result) > 0): ?>
                        <div class="orders-list">
                            <?php while($order = mysqli_fetch_assoc($orders_result)): ?>
                            <div class="order-item">
                                <div class="order-details">
                                    <p><strong>Order #<?php echo $order['id']; ?></strong></p>
                                    <p>Date: <?php echo date('M d, Y', strtotime($order['created_at'])); ?></p>
                                    <p>Items: <?php echo $order['item_count']; ?></p>
                                    <p>Total: £<?php echo number_format($order['total_amount'], 2); ?></p>
                                </div>
                                <div class="order-status">
                                    <span class="status status-<?php echo $order['status']; ?>">
                                        <?php echo ucfirst($order['status']); ?>
                                    </span>
                                    <a href="order_details.php?id=<?php echo $order['id']; ?>" class="btn btn-sm">View</a>
                                </div>
                            </div>
                            <?php endwhile; ?>
                        </div>
                        <a href="orders.php" class="btn btn-secondary">View All Orders</a>
                    <?php else: ?>
                        <p>No orders yet. <a href="products.php">Start shopping!</a></p>
                    <?php endif; ?>
                </div>

                <div class="dashboard-section">
                    <h2>Quick Actions</h2>
                    <div class="quick-actions">
                        <a href="products.php" class="btn btn-primary">Browse Products</a>
                        <a href="cart.php" class="btn btn-secondary">View Cart</a>
                        <a href="profile.php" class="btn btn-secondary">Edit Profile</a>
                        <a href="orders.php" class="btn btn-secondary">Order History</a>
                    </div>
                </div>
            </div>
        </div>
    </main>

    <script src="js/main.js"></script>
</body>
</html>