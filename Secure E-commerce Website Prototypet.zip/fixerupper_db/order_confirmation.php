<?php
session_start();
require_once 'config.php';

if (!isset($_SESSION['user_id']) || !isset($_GET['order_id'])) {
    header("Location: index.php");
    exit();
}

$order_id = (int)$_GET['order_id'];
$user_id = $_SESSION['user_id'];

$order_query = "SELECT * FROM orders WHERE id = $order_id AND user_id = $user_id";
$order_result = mysqli_query($conn, $order_query);

if (mysqli_num_rows($order_result) == 0) {
    header("Location: dashboard.php");
    exit();
}

$order = mysqli_fetch_assoc($order_result);

$items_query = "SELECT oi.*, p.name, p.image FROM order_items oi 
                JOIN products p ON oi.product_id = p.id 
                WHERE oi.order_id = $order_id";
$items_result = mysqli_query($conn, $items_query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Order Confirmation - FixerUpper</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <header>
        <nav class="navbar">
            <div class="nav-container">
                <div class="nav-logo">
                    <h2><a href="index.php">FixerUpper</a></h2>
                </div>
                <div class="nav-menu">
                    <a href="index.php">Home</a>
                    <a href="products.php">Products</a>
                    <a href="dashboard.php">Dashboard</a>
                    <a href="logout.php">Logout</a>
                </div>
            </div>
        </nav>
    </header>

    <main>
        <div class="confirmation-container">
            <div class="confirmation-header">
                <div class="success-icon">✓</div>
                <h1>Order Confirmed!</h1>
                <p>Thank you for your order. We'll send you updates about your order status.</p>
            </div>
            
            <div class="order-details">
                <div class="order-info">
                    <h2>Order Details</h2>
                    <div class="info-grid">
                        <div class="info-item">
                            <strong>Order Number:</strong>
                            <span>#<?php echo $order['id']; ?></span>
                        </div>
                        <div class="info-item">
                            <strong>Order Date:</strong>
                            <span><?php echo date('M d, Y H:i', strtotime($order['created_at'])); ?></span>
                        </div>
                        <div class="info-item">
                            <strong>Delivery Method:</strong>
                            <span><?php echo ucfirst(str_replace('_', ' ', $order['delivery_method'])); ?></span>
                        </div>
                        <div class="info-item">
                            <strong>Payment Method:</strong>
                            <span><?php echo ucfirst(str_replace('_', ' ', $order['payment_method'])); ?></span>
                        </div>
                        <div class="info-item">
                            <strong>Status:</strong>
                            <span class="status status-<?php echo $order['status']; ?>">
                                <?php echo ucfirst($order['status']); ?>
                            </span>
                        </div>
                    </div>
                </div>
                
                <div class="order-items">
                    <h3>Items Ordered</h3>
                    <div class="items-list">
                        <?php while ($item = mysqli_fetch_assoc($items_result)): ?>
                        <div class="order-item">
                            <img src="<?php echo htmlspecialchars($item['image']); ?>" alt="<?php echo htmlspecialchars($item['name']); ?>">
                            <div class="item-details">
                                <h4><?php echo htmlspecialchars($item['name']); ?></h4>
                                <p>Quantity: <?php echo $item['quantity']; ?></p>
                                <p>Price: £<?php echo number_format($item['price'], 2); ?> each</p>
                            </div>
                            <div class="item-total">
                                £<?php echo number_format($item['price'] * $item['quantity'], 2); ?>
                            </div>
                        </div>
                        <?php endwhile; ?>
                    </div>
                </div>
                
                <div class="order-summary">
                    <div class="summary-row">
                        <span>Subtotal:</span>
                        <span>£<?php echo number_format($order['total_amount'], 2); ?></span>
                    </div>
                    <div class="summary-row">
                        <span>Shipping:</span>
                        <span><?php echo $order['shipping_cost'] > 0 ? '£' . number_format($order['shipping_cost'], 2) : 'FREE'; ?></span>
                    </div>
                    <div class="summary-row total">
                        <span>Total:</span>
                        <span>£<?php echo number_format($order['total_amount'] + $order['shipping_cost'], 2); ?></span>
                    </div>
                </div>
                
                <?php if (!empty($order['delivery_address'])): ?>
                <div class="delivery-info">
                    <h3>Delivery Address</h3>
                    <p><?php echo nl2br(htmlspecialchars($order['delivery_address'])); ?></p>
                    <?php if (!empty($order['special_instructions'])): ?>
                        <h4>Special Instructions</h4>
                        <p><?php echo nl2br(htmlspecialchars($order['special_instructions'])); ?></p>
                    <?php endif; ?>
                </div>
                <?php endif; ?>
                
                <div class="next-steps">
                    <h3>What happens next?</h3>
                    <ul>
                        <?php if ($order['delivery_method'] == 'home_delivery'): ?>
                            <li>We'll prepare your order for delivery</li>
                            <li>You'll receive a tracking number once shipped</li>
                            <li>Estimated delivery: 2-3 business days</li>
                        <?php else: ?>
                            <li>We'll prepare your order for collection</li>
                            <li>You'll receive a notification when ready</li>
                            <li>Collect from our Newcastle store</li>
                        <?php endif; ?>
                        <li>You'll receive email updates about your order status</li>
                    </ul>
                </div>
                
                <div class="confirmation-actions">
                    <a href="order_details.php?id=<?php echo $order['id']; ?>" class="btn btn-primary">View Order Details</a>
                    <a href="products.php" class="btn btn-secondary">Continue Shopping</a>
                    <a href="dashboard.php" class="btn btn-secondary">Go to Dashboard</a>
                </div>
            </div>
        </div>
    </main>

    <script src="js/main.js"></script>
</body>
</html>