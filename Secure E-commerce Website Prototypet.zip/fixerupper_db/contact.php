<?php
session_start();
require_once 'config.php';

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (!verify_csrf_token($_POST['csrf_token'])) {
        $error = 'Invalid request';
    } else {
        $name = sanitize_input($_POST['name']);
        $email = sanitize_input($_POST['email']);
        $phone = sanitize_input($_POST['phone']);
        $subject = sanitize_input($_POST['subject']);
        $message = sanitize_input($_POST['message']);
        
        if (empty($name) || empty($email) || empty($subject) || empty($message)) {
            $error = 'Please fill in all required fields';
        } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $error = 'Invalid email format';
        } else {
            $insert_query = "INSERT INTO contact_messages (name, email, phone, subject, message, created_at) 
                            VALUES ('$name', '$email', '$phone', '$subject', '$message', NOW())";
            
            if (mysqli_query($conn, $insert_query)) {
                $success = 'Thank you for your message! We will get back to you within 24 hours.';
                $_POST = array();
            } else {
                $error = 'Failed to send message. Please try again.';
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact Us - FixerUpper</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <header>
        <nav class="navbar">
            <div class="nav-container">
                <div class="nav-logo">
                    <h2><a href="index.php">FixerUpper</a></h2>
                </div>
                <div class="nav-menu">
                    <a href="index.php">Home</a>
                    <a href="products.php">Products</a>
                    <a href="about.php">About</a>
                    <a href="contact.php" class="active">Contact</a>
                    <?php if(isset($_SESSION['user_id'])): ?>
                        <a href="cart.php">Cart (<?php echo isset($_SESSION['cart']) ? count($_SESSION['cart']) : 0; ?>)</a>
                        <a href="dashboard.php">Dashboard</a>
                        <a href="logout.php">Logout</a>
                    <?php else: ?>
                        <a href="login.php">Login</a>
                        <a href="register.php">Register</a>
                    <?php endif; ?>
                </div>
            </div>
        </nav>
    </header>

    <main>
        <div class="contact-container">
            <div class="contact-header">
                <h1>Contact Us</h1>
                <p>Get in touch with our team for any questions or support</p>
            </div>
            
            <div class="contact-content">
                <div class="contact-form-section">
                    <h2>Send us a Message</h2>
                    
                    <?php if($error): ?>
                        <div class="alert alert-error"><?php echo $error; ?></div>
                    <?php endif; ?>
                    
                    <?php if($success): ?>
                        <div class="alert alert-success"><?php echo $success; ?></div>
                    <?php endif; ?>
                    
                    <form method="POST" action="" class="contact-form">
                        <input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>">
                        
                        <div class="form-row">
                            <div class="form-group">
                                <label for="name">Full Name *</label>
                                <input type="text" id="name" name="name" value="<?php echo isset($_POST['name']) ? htmlspecialchars($_POST['name']) : ''; ?>" required>
                            </div>
                            
                            <div class="form-group">
                                <label for="email">Email *</label>
                                <input type="email" id="email" name="email" value="<?php echo isset($_POST['email']) ? htmlspecialchars($_POST['email']) : ''; ?>" required>
                            </div>
                        </div>
                        
                        <div class="form-row">
                            <div class="form-group">
                                <label for="phone">Phone</label>
                                <input type="tel" id="phone" name="phone" value="<?php echo isset($_POST['phone']) ? htmlspecialchars($_POST['phone']) : ''; ?>">
                            </div>
                            
                            <div class="form-group">
                                <label for="subject">Subject *</label>
                                <select id="subject" name="subject" required>
                                    <option value="">Select a subject</option>
                                    <option value="general_inquiry" <?php echo (isset($_POST['subject']) && $_POST['subject'] == 'general_inquiry') ? 'selected' : ''; ?>>General Inquiry</option>
                                    <option value="product_question" <?php echo (isset($_POST['subject']) && $_POST['subject'] == 'product_question') ? 'selected' : ''; ?>>Product Question</option>
                                    <option value="order_support" <?php echo (isset($_POST['subject']) && $_POST['subject'] == 'order_support') ? 'selected' : ''; ?>>Order Support</option>
                                    <option value="technical_support" <?php echo (isset($_POST['subject']) && $_POST['subject'] == 'technical_support') ? 'selected' : ''; ?>>Technical Support</option>
                                    <option value="complaint" <?php echo (isset($_POST['subject']) && $_POST['subject'] == 'complaint') ? 'selected' : ''; ?>>Complaint</option>
                                    <option value="other" <?php echo (isset($_POST['subject']) && $_POST['subject'] == 'other') ? 'selected' : ''; ?>>Other</option>
                                </select>
                            </div>
                        </div>
                        
                        <div class="form-group">
                            <label for="message">Message *</label>
                            <textarea id="message" name="message" rows="6" required><?php echo isset($_POST['message']) ? htmlspecialchars($_POST['message']) : ''; ?></textarea>
                        </div>
                        
                        <button type="submit" class="btn btn-primary">Send Message</button>
                    </form>
                </div>
                
                <div class="contact-info-section">
                    <div class="contact-info">
                        <h2>Get in Touch</h2>
                        
                        <div class="contact-method">
                            <h3>Store Location</h3>
                            <p>123 Hardware Street<br>
                            Newcastle, NE1 4AB<br>
                            United Kingdom</p>
                        </div>
                        
                        <div class="contact-method">
                            <h3>Phone</h3>
                            <p><a href="tel:01911234567">0191 123 4567</a></p>
                            <p class="contact-note">Monday - Friday: 8:00 AM - 6:00 PM<br>
                            Saturday: 9:00 AM - 5:00 PM<br>
                            Sunday: 10:00 AM - 4:00 PM</p>
                        </div>
                        
                        <div class="contact-method">
                            <h3>Email</h3>
                            <p><a href="mailto:info@fixerupper.co.uk">info@fixerupper.co.uk</a></p>
                            <p class="contact-note">We typically respond within 24 hours</p>
                        </div>
                        
                        <div class="contact-method">
                            <h3>Emergency Support</h3>
                            <p><a href="tel:01911234999">0191 123 4999</a></p>
                            <p class="contact-note">For urgent technical issues only<br>
                            Available 24/7</p>
                        </div>
                    </div>
                    
                    <div class="faq-section">
                        <h3>Frequently Asked Questions</h3>
                        <div class="faq-item">
                            <strong>Q: What are your delivery options?</strong>
                            <p>We offer home delivery (£5.99, free over £50) and in-store collection.</p>
                        </div>
                        
                        <div class="faq-item">
                            <strong>Q: Do you offer installation services?</strong>
                            <p>Yes, we provide professional installation for most appliances.</p>
                        </div>
                        
                        <div class="faq-item">
                            <strong>Q: What is your return policy?</strong>
                            <p>30-day returns on unused items with original packaging.</p>
                        </div>
                        
                        <div class="faq-item">
                            <strong>Q: Do you price match?</strong>
                            <p>Yes, we match legitimate competitor prices on identical products.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>

    <footer>
        <div class="container">
            <p>&copy; 2025 FixerUpper. All rights reserved.</p>
        </div>
    </footer>

    <script src="js/main.js"></script>
</body>
</html>