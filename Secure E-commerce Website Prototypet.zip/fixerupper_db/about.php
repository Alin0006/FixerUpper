<?php
session_start();
require_once 'config.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About Us - FixerUpper</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <header>
        <nav class="navbar">
            <div class="nav-container">
                <div class="nav-logo">
                    <h2><a href="index.php">FixerUpper</a></h2>
                </div>
                <div class="nav-menu">
                    <a href="index.php">Home</a>
                    <a href="products.php">Products</a>
                    <a href="about.php" class="active">About</a>
                    <a href="contact.php">Contact</a>
                    <?php if(isset($_SESSION['user_id'])): ?>
                        <a href="cart.php">Cart (<?php echo isset($_SESSION['cart']) ? count($_SESSION['cart']) : 0; ?>)</a>
                        <a href="dashboard.php">Dashboard</a>
                        <a href="logout.php">Logout</a>
                    <?php else: ?>
                        <a href="login.php">Login</a>
                        <a href="register.php">Register</a>
                    <?php endif; ?>
                </div>
            </div>
        </nav>
    </header>

    <main>
        <div class="about-container">
            <section class="about-hero">
                <div class="hero-content">
                    <h1>About FixerUpper</h1>
                    <p>Your trusted partner for quality hardware appliances since 1995</p>
                </div>
            </section>

            <section class="about-content">
                <div class="container">
                    <div class="about-section">
                        <h2>Our Story</h2>
                        <p>Founded in 1995 in Newcastle, FixerUpper started as a small family-owned hardware store with a simple mission: to provide quality appliances and exceptional service to our local community. Over the years, we have grown from a single brick-and-mortar location to becoming a trusted name in hardware solutions.</p>
                        
                        <p>Our journey began when our founder, recognizing the need for reliable hardware appliances in the Newcastle area, opened our first store. What started as a modest operation has evolved into a comprehensive hardware solutions provider, serving both individual customers and businesses throughout the region.</p>
                    </div>

                    <div class="about-section">
                        <h2>Our Mission</h2>
                        <p>At FixerUpper, we are committed to providing our customers with the highest quality hardware appliances, expert advice, and exceptional service. We believe that the right tools and equipment can make all the difference in any project, whether it's a simple home repair or a complex industrial application.</p>
                        
                        <p>We strive to be more than just a supplier – we want to be your trusted partner in finding the perfect solutions for your hardware needs.</p>
                    </div>

                    <div class="values-grid">
                        <div class="value-item">
                            <h3>Quality First</h3>
                            <p>We carefully select every product in our inventory to ensure it meets our high standards for quality and reliability.</p>
                        </div>
                        
                        <div class="value-item">
                            <h3>Expert Knowledge</h3>
                            <p>Our team brings decades of combined experience in hardware and appliances to help you make informed decisions.</p>
                        </div>
                        
                        <div class="value-item">
                            <h3>Customer Service</h3>
                            <p>We believe in building lasting relationships with our customers through exceptional service and support.</p>
                        </div>
                        
                        <div class="value-item">
                            <h3>Local Community</h3>
                            <p>As a Newcastle-based business, we are proud to support our local community and contribute to its growth.</p>
                        </div>
                    </div>

                    <div class="about-section">
                        <h2>Why Choose FixerUpper?</h2>
                        <div class="benefits-list">
                            <div class="benefit-item">
                                <strong>Extensive Product Range:</strong> From basic tools to specialized industrial equipment, we have everything you need under one roof.
                            </div>
                            
                            <div class="benefit-item">
                                <strong>Competitive Pricing:</strong> We work hard to offer fair, competitive prices without compromising on quality.
                            </div>
                            
                            <div class="benefit-item">
                                <strong>Professional Installation:</strong> Our certified technicians can handle installation and setup for most appliances.
                            </div>
                            
                            <div class="benefit-item">
                                <strong>Flexible Delivery Options:</strong> Choose between convenient home delivery or in-store collection to suit your schedule.
                            </div>
                            
                            <div class="benefit-item">
                                <strong>Warranty Support:</strong> All our products come with manufacturer warranties, and we provide ongoing support.
                            </div>
                        </div>
                    </div>

                    <div class="about-section">
                        <h2>Our Transition to Digital</h2>
                        <p>While we remain proud of our brick-and-mortar roots, we recognize the changing needs of our customers. That's why we've expanded our services to include online shopping and delivery, making it easier than ever to access our products and expertise.</p>
                        
                        <p>Our new e-commerce platform represents our commitment to innovation while maintaining the personal service and quality that have defined FixerUpper for nearly three decades.</p>
                    </div>

                    <div class="location-info">
                        <h2>Visit Our Store</h2>
                        <div class="location-details">
                            <div class="location-item">
                                <strong>Address:</strong>
                                <p>123 Hardware Street<br>
                                Newcastle, NE1 4AB<br>
                                United Kingdom</p>
                            </div>
                            
                            <div class="location-item">
                                <strong>Opening Hours:</strong>
                                <p>Monday - Friday: 8:00 AM - 6:00 PM<br>
                                Saturday: 9:00 AM - 5:00 PM<br>
                                Sunday: 10:00 AM - 4:00 PM</p>
                            </div>
                            
                            <div class="location-item">
                                <strong>Contact:</strong>
                                <p>Phone: 0191 123 4567<br>
                                Email: info@fixerupper.co.uk</p>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </div>
    </main>

    <footer>
        <div class="container">
            <p>&copy; 2025 FixerUpper. All rights reserved.</p>
        </div>
    </footer>

    <script src="js/main.js"></script>
</body>
</html>