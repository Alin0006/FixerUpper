<?php
session_start();
require_once 'config.php';

if (!isset($_SESSION['user_id']) || !isset($_GET['id'])) {
    header("Location: dashboard.php");
    exit();
}

$order_id = (int)$_GET['id'];
$user_id = $_SESSION['user_id'];

$order_query = "SELECT * FROM orders WHERE id = $order_id AND user_id = $user_id";
$order_result = mysqli_query($conn, $order_query);

if (mysqli_num_rows($order_result) == 0) {
    header("Location: orders.php");
    exit();
}

$order = mysqli_fetch_assoc($order_result);

$items_query = "SELECT oi.*, p.name, p.image, p.category FROM order_items oi 
                JOIN products p ON oi.product_id = p.id 
                WHERE oi.order_id = $order_id";
$items_result = mysqli_query($conn, $items_query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Order #<?php echo $order['id']; ?> - FixerUpper</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <header>
        <nav class="navbar">
            <div class="nav-container">
                <div class="nav-logo">
                    <h2><a href="index.php">FixerUpper</a></h2>
                </div>
                <div class="nav-menu">
                    <a href="index.php">Home</a>
                    <a href="products.php">Products</a>
                    <a href="cart.php">Cart</a>
                    <a href="dashboard.php">Dashboard</a>
                    <a href="orders.php">Orders</a>
                    <a href="logout.php">Logout</a>
                </div>
            </div>
        </nav>
    </header>

    <main>
        <div class="order-details-container">
            <div class="order-header">
                <div class="header-content">
                    <h1>Order #<?php echo $order['id']; ?></h1>
                    <div class="order-meta">
                        <span class="status status-<?php echo $order['status']; ?>">
                            <?php echo ucfirst($order['status']); ?>
                        </span>
                        <span class="order-date">
                            Placed on <?php echo date('M d, Y H:i', strtotime($order['created_at'])); ?>
                        </span>
                    </div>
                </div>
                <div class="header-actions">
                    <a href="orders.php" class="btn btn-secondary">← Back to Orders</a>
                    <?php if ($order['status'] == 'pending'): ?>
                        <button class="btn btn-danger" onclick="cancelOrder(<?php echo $order['id']; ?>)">Cancel Order</button>
                    <?php endif; ?>
                </div>
            </div>

            <div class="order-content">
                <div class="order-items-section">
                    <h2>Items Ordered</h2>
                    <div class="order-items">
                        <?php while ($item = mysqli_fetch_assoc($items_result)): ?>
                        <div class="order-item">
                            <div class="item-image">
                                <img src="<?php echo htmlspecialchars($item['image']); ?>" alt="<?php echo htmlspecialchars($item['name']); ?>">
                            </div>
                            <div class="item-details">
                                <h3><?php echo htmlspecialchars($item['name']); ?></h3>
                                <p class="item-category"><?php echo ucfirst($item['category']); ?></p>
                                <p class="item-price">£<?php echo number_format($item['price'], 2); ?> each</p>
                                <p class="item-quantity">Quantity: <?php echo $item['quantity']; ?></p>
                            </div>
                            <div class="item-total">
                                £<?php echo number_format($item['price'] * $item['quantity'], 2); ?>
                            </div>
                        </div>
                        <?php endwhile; ?>
                    </div>
                </div>

                <div class="order-summary-section">
                    <h2>Order Summary</h2>
                    <div class="summary-card">
                        <div class="summary-row">
                            <span>Subtotal:</span>
                            <span>£<?php echo number_format($order['total_amount'], 2); ?></span>
                        </div>
                        <div class="summary-row">
                            <span>Shipping:</span>
                            <span><?php echo $order['shipping_cost'] > 0 ? '£' . number_format($order['shipping_cost'], 2) : 'FREE'; ?></span>
                        </div>
                        <div class="summary-row total">
                            <span>Total:</span>
                            <span>£<?php echo number_format($order['total_amount'] + $order['shipping_cost'], 2); ?></span>
                        </div>
                    </div>
                </div>

                <div class="order-info-section">
                    <div class="info-grid">
                        <div class="info-card">
                            <h3>Delivery Information</h3>
                            <p><strong>Method:</strong> <?php echo ucfirst(str_replace('_', ' ', $order['delivery_method'])); ?></p>
                            <?php if (!empty($order['delivery_address'])): ?>
                                <p><strong>Address:</strong></p>
                                <p><?php echo nl2br(htmlspecialchars($order['delivery_address'])); ?></p>
                            <?php endif; ?>
                            <?php if (!empty($order['special_instructions'])): ?>
                                <p><strong>Special Instructions:</strong></p>
                                <p><?php echo nl2br(htmlspecialchars($order['special_instructions'])); ?></p>
                            <?php endif; ?>
                        </div>

                        <div class="info-card">
                            <h3>Payment Information</h3>
                            <p><strong>Method:</strong> <?php echo ucfirst(str_replace('_', ' ', $order['payment_method'])); ?></p>
                            <p><strong>Status:</strong> 
                                <span class="payment-status <?php echo $order['status'] == 'cancelled' ? 'refunded' : 'paid'; ?>">
                                    <?php echo $order['status'] == 'cancelled' ? 'Refunded' : 'Paid'; ?>
                                </span>
                            </p>
                        </div>

                        <div class="info-card">
                            <h3>Billing Address</h3>
                            <p><?php echo nl2br(htmlspecialchars($order['billing_address'])); ?></p>
                        </div>

                        <div class="info-card">
                            <h3>Order Status</h3>
                            <div class="status-timeline">
                                <div class="status-step <?php echo in_array($order['status'], ['pending', 'processing', 'shipped', 'delivered']) ? 'completed' : ''; ?>">
                                    <span class="step-icon">1</span>
                                    <span class="step-text">Order Placed</span>
                                </div>
                                <div class="status-step <?php echo in_array($order['status'], ['processing', 'shipped', 'delivered']) ? 'completed' : ''; ?>">
                                    <span class="step-icon">2</span>
                                    <span class="step-text">Processing</span>
                                </div>
                                <div class="status-step <?php echo in_array($order['status'], ['shipped', 'delivered']) ? 'completed' : ''; ?>">
                                    <span class="step-icon">3</span>
                                    <span class="step-text">Shipped</span>
                                </div>
                                <div class="status-step <?php echo $order['status'] == 'delivered' ? 'completed' : ''; ?>">
                                    <span class="step-icon">4</span>
                                    <span class="step-text">Delivered</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>

    <script src="js/main.js"></script>
    <script>
        function cancelOrder(orderId) {
            if (confirm('Are you sure you want to cancel this order?')) {
                fetch('cancel_order.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded',
                    },
                    body: 'order_id=' + orderId + '&csrf_token=' + getCsrfToken()
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        location.reload();
                    } else {
                        alert('Failed to cancel order: ' + data.message);
                    }
                });
            }
        }
        
        function getCsrfToken() {
            return document.querySelector('meta[name="csrf-token"]')?.getAttribute('content') || '';
        }
    </script>
</body>
</html>