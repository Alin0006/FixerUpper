<?php
session_start();
require_once 'config.php';

$sql = "SELECT * FROM products WHERE status = 'active' ORDER BY created_at DESC LIMIT 8";
$result = mysqli_query($conn, $sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>FixerUpper - Hardware Appliances</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <header>
        <nav class="navbar">
            <div class="nav-container">
                <div class="nav-logo">
                    <h2>FixerUpper</h2>
                </div>
                <div class="nav-menu">
                    <a href="index.php">Home</a>
                    <a href="products.php">Products</a>
                    <a href="about.php">About</a>
                    <a href="contact.php">Contact</a>
                    <?php if(isset($_SESSION['user_id'])): ?>
                        <a href="cart.php">Cart (<?php echo isset($_SESSION['cart']) ? count($_SESSION['cart']) : 0; ?>)</a>
                        <a href="dashboard.php">Dashboard</a>
                        <a href="logout.php">Logout</a>
                    <?php else: ?>
                        <a href="login.php">Login</a>
                        <a href="register.php">Register</a>
                    <?php endif; ?>
                </div>
            </div>
        </nav>
    </header>

    <main>
        <section class="hero">
            <div class="hero-content">
                <h1>Quality Hardware Appliances</h1>
                <p>Your trusted partner for professional hardware solutions</p>
                <a href="products.php" class="btn btn-primary">Shop Now</a>
            </div>
        </section>

        <section class="featured-products">
            <div class="container">
                <h2>Featured Products</h2>
                <div class="products-grid">
                    <?php while($product = mysqli_fetch_assoc($result)): ?>
                    <div class="product-card">
                        <img src="<?php echo htmlspecialchars($product['image']); ?>" alt="<?php echo htmlspecialchars($product['name']); ?>">
                        <div class="product-info">
                            <h3><?php echo htmlspecialchars($product['name']); ?></h3>
                            <p class="price">£<?php echo number_format($product['price'], 2); ?></p>
                            <p class="description"><?php echo htmlspecialchars(substr($product['description'], 0, 100)); ?>...</p>
                            <a href="product_details.php?id=<?php echo $product['id']; ?>" class="btn btn-secondary">View Details</a>
                        </div>
                    </div>
                    <?php endwhile; ?>
                </div>
            </div>
        </section>

        <section class="services">
            <div class="container">
                <h2>Our Services</h2>
                <div class="services-grid">
                    <div class="service-item">
                        <h3>Home Delivery</h3>
                        <p>Fast and secure delivery to your doorstep</p>
                    </div>
                    <div class="service-item">
                        <h3>In-Store Collection</h3>
                        <p>Collect your order from our Newcastle store</p>
                    </div>
                    <div class="service-item">
                        <h3>Professional Installation</h3>
                        <p>Expert installation services available</p>
                    </div>
                </div>
            </div>
        </section>
    </main>

    <footer>
        <div class="container">
            <p>&copy; 2025 FixerUpper. All rights reserved.</p>
        </div>
    </footer>

    <script src="js/main.js"></script>
</body>
</html>