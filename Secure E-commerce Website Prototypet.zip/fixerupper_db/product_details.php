<?php
session_start();
require_once 'config.php';

if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    header("Location: products.php");
    exit();
}

$product_id = (int)$_GET['id'];
$query = "SELECT * FROM products WHERE id = $product_id AND status = 'active'";
$result = mysqli_query($conn, $query);

if (mysqli_num_rows($result) == 0) {
    header("Location: products.php");
    exit();
}

$product = mysqli_fetch_assoc($result);

$related_query = "SELECT * FROM products WHERE category = '{$product['category']}' AND id != $product_id AND status = 'active' LIMIT 4";
$related_result = mysqli_query($conn, $related_query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($product['name']); ?> - FixerUpper</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <header>
        <nav class="navbar">
            <div class="nav-container">
                <div class="nav-logo">
                    <h2><a href="index.php">FixerUpper</a></h2>
                </div>
                <div class="nav-menu">
                    <a href="index.php">Home</a>
                    <a href="products.php">Products</a>
                    <a href="about.php">About</a>
                    <a href="contact.php">Contact</a>
                    <?php if(isset($_SESSION['user_id'])): ?>
                        <a href="cart.php">Cart (<?php echo isset($_SESSION['cart']) ? count($_SESSION['cart']) : 0; ?>)</a>
                        <a href="dashboard.php">Dashboard</a>
                        <a href="logout.php">Logout</a>
                    <?php else: ?>
                        <a href="login.php">Login</a>
                        <a href="register.php">Register</a>
                    <?php endif; ?>
                </div>
            </div>
        </nav>
    </header>

    <main>
        <div class="product-details-container">
            <div class="product-details">
                <div class="product-image">
                    <img src="<?php echo htmlspecialchars($product['image']); ?>" alt="<?php echo htmlspecialchars($product['name']); ?>">
                </div>
                
                <div class="product-info">
                    <nav class="breadcrumb">
                        <a href="index.php">Home</a> > 
                        <a href="products.php">Products</a> > 
                        <a href="products.php?category=<?php echo $product['category']; ?>"><?php echo ucfirst($product['category']); ?></a> > 
                        <span><?php echo htmlspecialchars($product['name']); ?></span>
                    </nav>
                    
                    <h1><?php echo htmlspecialchars($product['name']); ?></h1>
                    <p class="category">Category: <?php echo ucfirst($product['category']); ?></p>
                    <p class="price">£<?php echo number_format($product['price'], 2); ?></p>
                    
                    <div class="product-description">
                        <h3>Description</h3>
                        <p><?php echo nl2br(htmlspecialchars($product['description'])); ?></p>
                    </div>
                    
                    <?php if ($product['stock_quantity'] > 0): ?>
                        <div class="stock-info">
                            <p class="in-stock">In Stock (<?php echo $product['stock_quantity']; ?> available)</p>
                        </div>
                        
                        <form method="POST" action="add_to_cart.php" class="add-to-cart-form">
                            <input type="hidden" name="product_id" value="<?php echo $product['id']; ?>">
                            <input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>">
                            
                            <div class="quantity-selector">
                                <label for="quantity">Quantity:</label>
                                <input type="number" id="quantity" name="quantity" value="1" min="1" max="<?php echo $product['stock_quantity']; ?>">
                            </div>
                            
                            <button type="submit" class="btn btn-primary btn-large">Add to Cart</button>
                        </form>
                    <?php else: ?>
                        <div class="stock-info">
                            <p class="out-of-stock">Out of Stock</p>
                        </div>
                    <?php endif; ?>
                    
                    <div class="product-features">
                        <h3>Features</h3>
                        <ul>
                            <li>Free delivery on orders over £50</li>
                            <li>In-store collection available</li>
                            <li>Professional installation service</li>
                            <li>12-month warranty included</li>
                        </ul>
                    </div>
                </div>
            </div>
            
            <?php if (mysqli_num_rows($related_result) > 0): ?>
            <div class="related-products">
                <h2>Related Products</h2>
                <div class="products-grid">
                    <?php while($related = mysqli_fetch_assoc($related_result)): ?>
                    <div class="product-card">
                        <img src="<?php echo htmlspecialchars($related['image']); ?>" alt="<?php echo htmlspecialchars($related['name']); ?>">
                        <div class="product-info">
                            <h3><?php echo htmlspecialchars($related['name']); ?></h3>
                            <p class="price">£<?php echo number_format($related['price'], 2); ?></p>
                            <a href="product_details.php?id=<?php echo $related['id']; ?>" class="btn btn-secondary">View Details</a>
                        </div>
                    </div>
                    <?php endwhile; ?>
                </div>
            </div>
            <?php endif; ?>
        </div>
    </main>

    <script src="js/main.js"></script>
</body>
</html>