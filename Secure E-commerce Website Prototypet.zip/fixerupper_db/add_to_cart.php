<?php
session_start();
require_once 'config.php';

if ($_SERVER['REQUEST_METHOD'] != 'POST') {
    header("Location: products.php");
    exit();
}

if (!verify_csrf_token($_POST['csrf_token'])) {
    header("Location: products.php");
    exit();
}

$product_id = (int)$_POST['product_id'];
$quantity = isset($_POST['quantity']) ? (int)$_POST['quantity'] : 1;

if ($quantity <= 0) {
    $quantity = 1;
}

$query = "SELECT * FROM products WHERE id = $product_id AND status = 'active'";
$result = mysqli_query($conn, $query);

if (mysqli_num_rows($result) == 0) {
    header("Location: products.php");
    exit();
}

$product = mysqli_fetch_assoc($result);

if ($product['stock_quantity'] < $quantity) {
    $_SESSION['error'] = 'Not enough stock available';
    header("Location: product_details.php?id=" . $product_id);
    exit();
}

if (!isset($_SESSION['cart'])) {
    $_SESSION['cart'] = [];
}

if (isset($_SESSION['cart'][$product_id])) {
    $new_quantity = $_SESSION['cart'][$product_id] + $quantity;
    if ($new_quantity > $product['stock_quantity']) {
        $_SESSION['error'] = 'Cannot add more items than available in stock';
        header("Location: product_details.php?id=" . $product_id);
        exit();
    }
    $_SESSION['cart'][$product_id] = $new_quantity;
} else {
    $_SESSION['cart'][$product_id] = $quantity;
}

$_SESSION['success'] = 'Product added to cart successfully!';
header("Location: cart.php");
exit();
?>