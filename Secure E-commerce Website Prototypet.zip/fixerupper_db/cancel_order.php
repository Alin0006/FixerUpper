<?php
session_start();
require_once 'config.php';

if ($_SERVER['REQUEST_METHOD'] != 'POST') {
    header("Location: orders.php");
    exit();
}

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

if (!verify_csrf_token($_POST['csrf_token'])) {
    $_SESSION['error'] = 'Invalid request';
    header("Location: orders.php");
    exit();
}

$order_id = (int)$_POST['order_id'];
$user_id = $_SESSION['user_id'];

$order_query = "SELECT * FROM orders WHERE id = $order_id AND user_id = $user_id AND status = 'pending'";
$order_result = mysqli_query($conn, $order_query);

if (mysqli_num_rows($order_result) == 0) {
    $_SESSION['error'] = 'Order not found or cannot be cancelled';
    header("Location: orders.php");
    exit();
}

mysqli_begin_transaction($conn);

try {
    $update_order = "UPDATE orders SET status = 'cancelled' WHERE id = $order_id";
    if (!mysqli_query($conn, $update_order)) {
        throw new Exception('Failed to update order status');
    }
    
    $items_query = "SELECT product_id, quantity FROM order_items WHERE order_id = $order_id";
    $items_result = mysqli_query($conn, $items_query);
    
    while ($item = mysqli_fetch_assoc($items_result)) {
        $product_id = $item['product_id'];
        $quantity = $item['quantity'];
        
        $update_stock = "UPDATE products SET stock_quantity = stock_quantity + $quantity WHERE id = $product_id";
        if (!mysqli_query($conn, $update_stock)) {
            throw new Exception('Failed to restore stock');
        }
    }
    
    mysqli_commit($conn);
    $_SESSION['success'] = 'Order cancelled successfully';
    
} catch (Exception $e) {
    mysqli_rollback($conn);
    $_SESSION['error'] = 'Failed to cancel order';
}

header("Location: orders.php");
exit();
?>