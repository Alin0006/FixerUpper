<?php
session_start();
require_once 'config.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$per_page = 10;
$offset = ($page - 1) * $per_page;

$count_query = "SELECT COUNT(*) as total FROM orders WHERE user_id = $user_id";
$count_result = mysqli_query($conn, $count_query);
$total_orders = mysqli_fetch_assoc($count_result)['total'];
$total_pages = ceil($total_orders / $per_page);

$orders_query = "SELECT o.*, COUNT(oi.id) as item_count 
                FROM orders o 
                LEFT JOIN order_items oi ON o.id = oi.order_id 
                WHERE o.user_id = $user_id 
                GROUP BY o.id 
                ORDER BY o.created_at DESC 
                LIMIT $per_page OFFSET $offset";
$orders_result = mysqli_query($conn, $orders_query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Order History - FixerUpper</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <header>
        <nav class="navbar">
            <div class="nav-container">
                <div class="nav-logo">
                    <h2><a href="index.php">FixerUpper</a></h2>
                </div>
                <div class="nav-menu">
                    <a href="index.php">Home</a>
                    <a href="products.php">Products</a>
                    <a href="cart.php">Cart</a>
                    <a href="dashboard.php">Dashboard</a>
                    <a href="orders.php" class="active">Orders</a>
                    <a href="logout.php">Logout</a>
                </div>
            </div>
        </nav>
    </header>

    <main>
        <div class="orders-container">
            <div class="orders-header">
                <h1>Order History</h1>
                <p>View and track all your orders</p>
            </div>
            
            <?php if (mysqli_num_rows($orders_result) > 0): ?>
                <div class="orders-list">
                    <?php while ($order = mysqli_fetch_assoc($orders_result)): ?>
                    <div class="order-card">
                        <div class="order-header">
                            <div class="order-number">
                                <h3>Order #<?php echo $order['id']; ?></h3>
                                <p>Placed on <?php echo date('M d, Y', strtotime($order['created_at'])); ?></p>
                            </div>
                            <div class="order-status">
                                <span class="status status-<?php echo $order['status']; ?>">
                                    <?php echo ucfirst($order['status']); ?>
                                </span>
                            </div>
                        </div>
                        
                        <div class="order-details">
                            <div class="order-info">
                                <div class="info-item">
                                    <span class="label">Items:</span>
                                    <span><?php echo $order['item_count']; ?> item(s)</span>
                                </div>
                                <div class="info-item">
                                    <span class="label">Total:</span>
                                    <span>£<?php echo number_format($order['total_amount'] + $order['shipping_cost'], 2); ?></span>
                                </div>
                                <div class="info-item">
                                    <span class="label">Delivery:</span>
                                    <span><?php echo ucfirst(str_replace('_', ' ', $order['delivery_method'])); ?></span>
                                </div>
                                <div class="info-item">
                                    <span class="label">Payment:</span>
                                    <span><?php echo ucfirst(str_replace('_', ' ', $order['payment_method'])); ?></span>
                                </div>
                            </div>
                        </div>
                        
                        <div class="order-actions">
                            <a href="order_details.php?id=<?php echo $order['id']; ?>" class="btn btn-primary">View Details</a>
                            
                            <?php if ($order['status'] == 'pending'): ?>
                                <button class="btn btn-danger" onclick="cancelOrder(<?php echo $order['id']; ?>)">Cancel Order</button>
                            <?php endif; ?>
                            
                            <?php if ($order['status'] == 'delivered'): ?>
                                <a href="reorder.php?id=<?php echo $order['id']; ?>" class="btn btn-secondary">Reorder</a>
                            <?php endif; ?>
                        </div>
                    </div>
                    <?php endwhile; ?>
                </div>
                
                <?php if ($total_pages > 1): ?>
                <div class="pagination">
                    <?php if ($page > 1): ?>
                        <a href="?page=<?php echo ($page - 1); ?>" class="btn btn-secondary">Previous</a>
                    <?php endif; ?>
                    
                    <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                        <a href="?page=<?php echo $i; ?>" 
                           class="btn <?php echo ($i == $page) ? 'btn-primary' : 'btn-secondary'; ?>">
                            <?php echo $i; ?>
                        </a>
                    <?php endfor; ?>
                    
                    <?php if ($page < $total_pages): ?>
                        <a href="?page=<?php echo ($page + 1); ?>" class="btn btn-secondary">Next</a>
                    <?php endif; ?>
                </div>
                <?php endif; ?>
                
            <?php else: ?>
                <div class="no-orders">
                    <h2>No orders found</h2>
                    <p>You haven't placed any orders yet.</p>
                    <a href="products.php" class="btn btn-primary">Start Shopping</a>
                </div>
            <?php endif; ?>
        </div>
    </main>

    <script src="js/main.js"></script>
    <script>
        function cancelOrder(orderId) {
            if (confirm('Are you sure you want to cancel this order?')) {
                fetch('cancel_order.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded',
                    },
                    body: 'order_id=' + orderId + '&csrf_token=' + getCsrfToken()
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        location.reload();
                    } else {
                        alert('Failed to cancel order: ' + data.message);
                    }
                });
            }
        }
        
        function getCsrfToken() {
            return document.querySelector('meta[name="csrf-token"]')?.getAttribute('content') || '';
        }
    </script>
</body>
</html>