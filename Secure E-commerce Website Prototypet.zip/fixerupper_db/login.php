<?php
session_start();
require_once 'config.php';

ini_set('display_errors', 1);
error_reporting(E_ALL);

$error = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (!verify_csrf_token($_POST['csrf_token'])) {
        $error = 'Invalid request';
    } else {
        $email = sanitize_input($_POST['email']);
        $password = $_POST['password'];
        
        if (empty($email) || empty($password)) {
            $error = 'Please fill in all fields';
        } elseif ($email == 'admin' && $password == 'admin') {
            $_SESSION['user_id'] = 999;
            $_SESSION['user_name'] = 'Admin User';
            $_SESSION['user_email'] = 'admin';
            $_SESSION['user_role'] = 'admin';
            
            if (isset($_GET['redirect'])) {
                header("Location: " . $_GET['redirect']);
            } else {
                header("Location: admin.php");
            }
            exit();
        } else {
            $query = "SELECT id, first_name, last_name, email, password, role FROM users WHERE email = '$email' AND status = 'active'";
            $result = mysqli_query($conn, $query);
            
            if (mysqli_num_rows($result) == 1) {
                $user = mysqli_fetch_assoc($result);
                
                if (password_verify($password, $user['password'])) {
                    $_SESSION['user_id'] = $user['id'];
                    $_SESSION['user_name'] = $user['first_name'] . ' ' . $user['last_name'];
                    $_SESSION['user_email'] = $user['email'];
                    $_SESSION['user_role'] = $user['role'];
                    
                    $update_login = "UPDATE users SET last_login = NOW() WHERE id = " . $user['id'];
                    mysqli_query($conn, $update_login);
                    
                    if (isset($_GET['redirect'])) {
                        header("Location: " . $_GET['redirect']);
                    } else {
                        header("Location: dashboard.php");
                    }
                    exit();
                } else {
                    $error = 'Invalid email or password';
                }
            } else {
                $error = 'Invalid email or password';
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - FixerUpper</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <header>
        <nav class="navbar">
            <div class="nav-container">
                <div class="nav-logo">
                    <h2><a href="index.php">FixerUpper</a></h2>
                </div>
                <div class="nav-menu">
                    <a href="index.php">Home</a>
                    <a href="products.php">Products</a>
                    <a href="register.php">Register</a>
                </div>
            </div>
        </nav>
    </header>

    <main>
        <div class="auth-container">
            <div class="auth-form">
                <h2>Login</h2>
                
                <?php if($error): ?>
                    <div class="alert alert-error"><?php echo $error; ?></div>
                <?php endif; ?>
                
                <form method="POST" action="">
                    <input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>">
                    
                    <div class="form-group">
                        <label for="email">Email</label>
                        <input type="text" id="email" name="email" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="password">Password</label>
                        <input type="password" id="password" name="password" required>
                    </div>
                    
                    <button type="submit" class="btn btn-primary">Login</button>
                </form>
                
                <p class="auth-link">Don't have an account? <a href="register.php">Register here</a></p>
            </div>
        </div>
    </main>

    <script src="js/main.js"></script>
</body>
</html>