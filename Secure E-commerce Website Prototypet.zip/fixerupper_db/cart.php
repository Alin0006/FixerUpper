<?php
session_start();
require_once 'config.php';

if (!isset($_SESSION['cart'])) {
    $_SESSION['cart'] = [];
}

$cart_items = [];
$total_amount = 0;

if (!empty($_SESSION['cart'])) {
    $product_ids = array_keys($_SESSION['cart']);
    $ids_string = implode(',', $product_ids);
    
    $query = "SELECT * FROM products WHERE id IN ($ids_string) AND status = 'active'";
    $result = mysqli_query($conn, $query);
    
    while ($product = mysqli_fetch_assoc($result)) {
        $quantity = $_SESSION['cart'][$product['id']];
        $subtotal = $product['price'] * $quantity;
        
        $cart_items[] = [
            'product' => $product,
            'quantity' => $quantity,
            'subtotal' => $subtotal
        ];
        
        $total_amount += $subtotal;
    }
}

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['action'])) {
    if (!verify_csrf_token($_POST['csrf_token'])) {
        $error = 'Invalid request';
    } else {
        if ($_POST['action'] == 'update') {
            $product_id = (int)$_POST['product_id'];
            $quantity = (int)$_POST['quantity'];
            
            if ($quantity > 0) {
                $_SESSION['cart'][$product_id] = $quantity;
            } else {
                unset($_SESSION['cart'][$product_id]);
            }
        } elseif ($_POST['action'] == 'remove') {
            $product_id = (int)$_POST['product_id'];
            unset($_SESSION['cart'][$product_id]);
        } elseif ($_POST['action'] == 'clear') {
            $_SESSION['cart'] = [];
        }
        
        header("Location: cart.php");
        exit();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Shopping Cart - FixerUpper</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <header>
        <nav class="navbar">
            <div class="nav-container">
                <div class="nav-logo">
                    <h2><a href="index.php">FixerUpper</a></h2>
                </div>
                <div class="nav-menu">
                    <a href="index.php">Home</a>
                    <a href="products.php">Products</a>
                    <a href="about.php">About</a>
                    <a href="contact.php">Contact</a>
                    <?php if(isset($_SESSION['user_id'])): ?>
                        <a href="cart.php" class="active">Cart (<?php echo count($_SESSION['cart']); ?>)</a>
                        <a href="dashboard.php">Dashboard</a>
                        <a href="logout.php">Logout</a>
                    <?php else: ?>
                        <a href="login.php">Login</a>
                        <a href="register.php">Register</a>
                    <?php endif; ?>
                </div>
            </div>
        </nav>
    </header>

    <main>
        <div class="cart-container">
            <h1>Shopping Cart</h1>
            
            <?php if (!empty($cart_items)): ?>
                <div class="cart-content">
                    <div class="cart-items">
                        <?php foreach ($cart_items as $item): ?>
                        <div class="cart-item">
                            <div class="item-image">
                                <img src="<?php echo htmlspecialchars($item['product']['image']); ?>" alt="<?php echo htmlspecialchars($item['product']['name']); ?>">
                            </div>
                            
                            <div class="item-details">
                                <h3><?php echo htmlspecialchars($item['product']['name']); ?></h3>
                                <p class="item-category"><?php echo ucfirst($item['product']['category']); ?></p>
                                <p class="item-price">£<?php echo number_format($item['product']['price'], 2); ?> each</p>
                            </div>
                            
                            <div class="item-quantity">
                                <form method="POST" action="" class="quantity-form">
                                    <input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>">
                                    <input type="hidden" name="action" value="update">
                                    <input type="hidden" name="product_id" value="<?php echo $item['product']['id']; ?>">
                                    <input type="number" name="quantity" value="<?php echo $item['quantity']; ?>" min="1" max="<?php echo $item['product']['stock_quantity']; ?>">
                                    <button type="submit" class="btn btn-sm">Update</button>
                                </form>
                            </div>
                            
                            <div class="item-subtotal">
                                <p>£<?php echo number_format($item['subtotal'], 2); ?></p>
                            </div>
                            
                            <div class="item-actions">
                                <form method="POST" action="">
                                    <input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>">
                                    <input type="hidden" name="action" value="remove">
                                    <input type="hidden" name="product_id" value="<?php echo $item['product']['id']; ?>">
                                    <button type="submit" class="btn btn-danger btn-sm">Remove</button>
                                </form>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                    
                    <div class="cart-summary">
                        <div class="summary-card">
                            <h3>Order Summary</h3>
                            
                            <div class="summary-row">
                                <span>Subtotal:</span>
                                <span>£<?php echo number_format($total_amount, 2); ?></span>
                            </div>
                            
                            <div class="summary-row">
                                <span>Shipping:</span>
                                <span><?php echo $total_amount >= 50 ? 'FREE' : '£5.99'; ?></span>
                            </div>
                            
                            <div class="summary-row total">
                                <span>Total:</span>
                                <span>£<?php echo number_format($total_amount + ($total_amount >= 50 ? 0 : 5.99), 2); ?></span>
                            </div>
                            
                            <?php if ($total_amount < 50): ?>
                                <p class="shipping-notice">Add £<?php echo number_format(50 - $total_amount, 2); ?> more for free shipping!</p>
                            <?php endif; ?>
                            
                            <div class="cart-actions">
                                <?php if (isset($_SESSION['user_id'])): ?>
                                    <a href="checkout.php" class="btn btn-primary btn-large">Proceed to Checkout</a>
                                <?php else: ?>
                                    <a href="login.php?redirect=checkout.php" class="btn btn-primary btn-large">Login to Checkout</a>
                                <?php endif; ?>
                                
                                <a href="products.php" class="btn btn-secondary">Continue Shopping</a>
                                
                                <form method="POST" action="">
                                    <input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>">
                                    <input type="hidden" name="action" value="clear">
                                    <button type="submit" class="btn btn-danger" onclick="return confirm('Are you sure you want to clear the cart?')">Clear Cart</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            <?php else: ?>
                <div class="empty-cart">
                    <h2>Your cart is empty</h2>
                    <p>Start shopping to add items to your cart!</p>
                    <a href="products.php" class="btn btn-primary">Browse Products</a>
                </div>
            <?php endif; ?>
        </div>
    </main>

    <script src="js/main.js"></script>
</body>
</html>