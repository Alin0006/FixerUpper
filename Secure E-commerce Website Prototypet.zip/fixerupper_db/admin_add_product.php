<?php
session_start();
require_once 'config.php';

if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] != 'admin') {
    header("Location: login.php");
    exit();
}

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (!verify_csrf_token($_POST['csrf_token'])) {
        $error = 'Invalid request';
    } else {
        $name = sanitize_input($_POST['name']);
        $description = sanitize_input($_POST['description']);
        $category = sanitize_input($_POST['category']);
        $price = floatval($_POST['price']);
        $stock_quantity = intval($_POST['stock_quantity']);
        $image_path = 'images/default-product.jpg';
        
        if (empty($name) || empty($description) || empty($category) || $price <= 0 || $stock_quantity < 0) {
            $error = 'Please fill in all required fields with valid values';
        } else {
            if (isset($_FILES['image']) && $_FILES['image']['error'] == 0) {
                $allowed_types = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
                $max_size = 5 * 1024 * 1024;
                
                if (!in_array($_FILES['image']['type'], $allowed_types)) {
                    $error = 'Invalid image type. Only JPG, PNG, GIF, and WebP are allowed.';
                } elseif ($_FILES['image']['size'] > $max_size) {
                    $error = 'Image size too large. Maximum 5MB allowed.';
                } else {
                    $upload_dir = 'images/products/';
                    if (!file_exists($upload_dir)) {
                        mkdir($upload_dir, 0777, true);
                    }
                    
                    $file_extension = pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION);
                    $new_filename = uniqid('product_') . '.' . $file_extension;
                    $upload_path = $upload_dir . $new_filename;
                    
                    if (move_uploaded_file($_FILES['image']['tmp_name'], $upload_path)) {
                        $image_path = $upload_path;
                    } else {
                        $error = 'Failed to upload image';
                    }
                }
            }
            
            if (empty($error)) {
                $insert_query = "INSERT INTO products (name, description, category, price, stock_quantity, image, status, created_at) 
                                VALUES ('$name', '$description', '$category', $price, $stock_quantity, '$image_path', 'active', NOW())";
                
                if (mysqli_query($conn, $insert_query)) {
                    $success = 'Product added successfully!';
                    $_POST = array();
                } else {
                    $error = 'Failed to add product: ' . mysqli_error($conn);
                }
            }
        }
    }
}

$categories_query = "SELECT DISTINCT category FROM products ORDER BY category";
$categories_result = mysqli_query($conn, $categories_query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add New Product - Admin</title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/admin.css">
</head>
<body>
    <header>
        <nav class="navbar">
            <div class="nav-container">
                <div class="nav-logo">
                    <h2><a href="admin.php">FixerUpper Admin</a></h2>
                </div>
                <div class="nav-menu">
                    <a href="admin.php">Dashboard</a>
                    <a href="admin_products.php">Products</a>
                    <a href="admin_orders.php">Orders</a>
                    <a href="admin_messages.php">Messages</a>
                    <a href="admin_users.php">Users</a>
                    <a href="index.php">View Site</a>
                    <a href="logout.php">Logout</a>
                </div>
            </div>
        </nav>
    </header>

    <main>
        <div class="admin-container">
            <div class="admin-header">
                <h1>Add New Product</h1>
                <a href="admin_products.php" class="btn btn-secondary">← Back to Products</a>
            </div>

            <?php if($success): ?>
                <div class="alert alert-success">
                    <?php echo $success; ?>
                    <a href="admin_products.php" class="btn btn-primary">View Products</a>
                </div>
            <?php endif; ?>
            
            <?php if($error): ?>
                <div class="alert alert-error"><?php echo $error; ?></div>
            <?php endif; ?>

            <div class="admin-form-container">
                <form method="POST" action="" enctype="multipart/form-data" class="admin-form">
                    <input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>">
                    
                    <div class="form-grid">
                        <div class="form-section">
                            <h3>Basic Information</h3>
                            
                            <div class="form-group">
                                <label for="name">Product Name *</label>
                                <input type="text" id="name" name="name" value="<?php echo isset($_POST['name']) ? htmlspecialchars($_POST['name']) : ''; ?>" required>
                            </div>
                            
                            <div class="form-group">
                                <label for="description">Description *</label>
                                <textarea id="description" name="description" rows="4" required><?php echo isset($_POST['description']) ? htmlspecialchars($_POST['description']) : ''; ?></textarea>
                            </div>
                            
                            <div class="form-row">
                                <div class="form-group">
                                    <label for="category">Category *</label>
                                    <select id="category" name="category" required>
                                        <option value="">Select Category</option>
                                        <?php while($cat = mysqli_fetch_assoc($categories_result)): ?>
                                            <option value="<?php echo $cat['category']; ?>" <?php echo (isset($_POST['category']) && $_POST['category'] == $cat['category']) ? 'selected' : ''; ?>>
                                                <?php echo ucfirst($cat['category']); ?>
                                            </option>
                                        <?php endwhile; ?>
                                        <option value="tools" <?php echo (isset($_POST['category']) && $_POST['category'] == 'tools') ? 'selected' : ''; ?>>Tools</option>
                                        <option value="appliances" <?php echo (isset($_POST['category']) && $_POST['category'] == 'appliances') ? 'selected' : ''; ?>>Appliances</option>
                                        <option value="garden" <?php echo (isset($_POST['category']) && $_POST['category'] == 'garden') ? 'selected' : ''; ?>>Garden</option>
                                        <option value="safety" <?php echo (isset($_POST['category']) && $_POST['category'] == 'safety') ? 'selected' : ''; ?>>Safety</option>
                                        <option value="electrical" <?php echo (isset($_POST['category']) && $_POST['category'] == 'electrical') ? 'selected' : ''; ?>>Electrical</option>
                                    </select>
                                    <small>Or select from existing categories above</small>
                                </div>
                                
                                <div class="form-group">
                                    <label for="new_category">Or Add New Category</label>
                                    <input type="text" id="new_category" name="new_category" placeholder="Enter new category name">
                                    <small>Leave empty to use selected category</small>
                                </div>
                            </div>
                        </div>

                        <div class="form-section">
                            <h3>Pricing & Stock</h3>
                            
                            <div class="form-row">
                                <div class="form-group">
                                    <label for="price">Price (£) *</label>
                                    <input type="number" id="price" name="price" step="0.01" min="0" value="<?php echo isset($_POST['price']) ? $_POST['price'] : ''; ?>" required>
                                </div>
                                
                                <div class="form-group">
                                    <label for="stock_quantity">Stock Quantity *</label>
                                    <input type="number" id="stock_quantity" name="stock_quantity" min="0" value="<?php echo isset($_POST['stock_quantity']) ? $_POST['stock_quantity'] : ''; ?>" required>
                                </div>
                            </div>
                        </div>

                        <div class="form-section">
                            <h3>Product Image</h3>
                            
                            <div class="form-group">
                                <label for="image">Product Image</label>
                                <input type="file" id="image" name="image" accept="image/*">
                                <small>Supported formats: JPG, PNG, GIF, WebP (Max 5MB)</small>
                            </div>
                            
                            <div class="image-preview" id="imagePreview" style="display: none;">
                                <img id="previewImg" src="" alt="Preview" style="max-width: 200px; max-height: 200px; border-radius: 8px;">
                            </div>
                        </div>
                    </div>
                    
                    <div class="form-actions">
                        <button type="submit" class="btn btn-primary btn-large">Add Product</button>
                        <a href="admin_products.php" class="btn btn-secondary">Cancel</a>
                    </div>
                </form>
            </div>
        </div>
    </main>

    <script src="js/main.js"></script>
    <script>
        
        document.getElementById('image').addEventListener('change', function(e) {
            const file = e.target.files[0];
            if (file) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    document.getElementById('previewImg').src = e.target.result;
                    document.getElementById('imagePreview').style.display = 'block';
                };
                reader.readAsDataURL(file);
            }
        });

        
        document.getElementById('new_category').addEventListener('input', function() {
            if (this.value.trim() !== '') {
                document.getElementById('category').value = '';
            }
        });

        document.getElementById('category').addEventListener('change', function() {
            if (this.value !== '') {
                document.getElementById('new_category').value = '';
            }
        });

       
        document.querySelector('.admin-form').addEventListener('submit', function(e) {
            const category = document.getElementById('category').value;
            const newCategory = document.getElementById('new_category').value.trim();
            
            if (!category && !newCategory) {
                e.preventDefault();
                alert('Please select a category or enter a new category name.');
                return false;
            }
            
            
            if (newCategory) {
                document.getElementById('category').value = newCategory.toLowerCase();
            }
        });
    </script>
</body>
</html>