<?php
session_start();
require_once 'config.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php?redirect=checkout.php");
    exit();
}

if (!isset($_SESSION['cart']) || empty($_SESSION['cart'])) {
    header("Location: cart.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$user_query = "SELECT * FROM users WHERE id = $user_id";
$user_result = mysqli_query($conn, $user_query);
$user = mysqli_fetch_assoc($user_result);

$cart_items = [];
$total_amount = 0;

$product_ids = array_keys($_SESSION['cart']);
$ids_string = implode(',', $product_ids);

$query = "SELECT * FROM products WHERE id IN ($ids_string) AND status = 'active'";
$result = mysqli_query($conn, $query);

while ($product = mysqli_fetch_assoc($result)) {
    $quantity = $_SESSION['cart'][$product['id']];
    $subtotal = $product['price'] * $quantity;
    
    $cart_items[] = [
        'product' => $product,
        'quantity' => $quantity,
        'subtotal' => $subtotal
    ];
    
    $total_amount += $subtotal;
}

$shipping_cost = $total_amount >= 50 ? 0 : 5.99;
$final_total = $total_amount + $shipping_cost;

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (!verify_csrf_token($_POST['csrf_token'])) {
        $error = 'Invalid request';
    } else {
        $delivery_method = sanitize_input($_POST['delivery_method']);
        $payment_method = sanitize_input($_POST['payment_method']);
        $billing_address = sanitize_input($_POST['billing_address']);
        $delivery_address = sanitize_input($_POST['delivery_address']);
        $special_instructions = sanitize_input($_POST['special_instructions']);
        
        if (empty($delivery_method) || empty($payment_method) || empty($billing_address)) {
            $error = 'Please fill in all required fields';
        } else {
            mysqli_begin_transaction($conn);
            
            try {
                $order_insert = "INSERT INTO orders (user_id, total_amount, shipping_cost, delivery_method, payment_method, billing_address, delivery_address, special_instructions, status, created_at) 
                                VALUES ($user_id, $total_amount, $shipping_cost, '$delivery_method', '$payment_method', '$billing_address', '$delivery_address', '$special_instructions', 'pending', NOW())";
                
                if (!mysqli_query($conn, $order_insert)) {
                    throw new Exception('Failed to create order');
                }
                
                $order_id = mysqli_insert_id($conn);
                
                foreach ($cart_items as $item) {
                    $product_id = $item['product']['id'];
                    $quantity = $item['quantity'];
                    $price = $item['product']['price'];
                    
                    $order_item_insert = "INSERT INTO order_items (order_id, product_id, quantity, price) 
                                         VALUES ($order_id, $product_id, $quantity, $price)";
                    
                    if (!mysqli_query($conn, $order_item_insert)) {
                        throw new Exception('Failed to add order items');
                    }
                    
                    $update_stock = "UPDATE products SET stock_quantity = stock_quantity - $quantity WHERE id = $product_id";
                    if (!mysqli_query($conn, $update_stock)) {
                        throw new Exception('Failed to update stock');
                    }
                }
                
                mysqli_commit($conn);
                unset($_SESSION['cart']);
                
                header("Location: order_confirmation.php?order_id=" . $order_id);
                exit();
                
            } catch (Exception $e) {
                mysqli_rollback($conn);
                $error = 'Order processing failed. Please try again.';
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Checkout - FixerUpper</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <header>
        <nav class="navbar">
            <div class="nav-container">
                <div class="nav-logo">
                    <h2><a href="index.php">FixerUpper</a></h2>
                </div>
                <div class="nav-menu">
                    <a href="index.php">Home</a>
                    <a href="products.php">Products</a>
                    <a href="cart.php">Cart</a>
                    <a href="dashboard.php">Dashboard</a>
                    <a href="logout.php">Logout</a>
                </div>
            </div>
        </nav>
    </header>

    <main>
        <div class="checkout-container">
            <h1>Checkout</h1>
            
            <?php if($error): ?>
                <div class="alert alert-error"><?php echo $error; ?></div>
            <?php endif; ?>
            
            <div class="checkout-content">
                <div class="checkout-form">
                    <form method="POST" action="">
                        <input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>">
                        
                        <div class="form-section">
                            <h3>Delivery Method</h3>
                            <div class="radio-group">
                                <label>
                                    <input type="radio" name="delivery_method" value="home_delivery" checked>
                                    Home Delivery (£<?php echo number_format($shipping_cost, 2); ?>)
                                </label>
                                <label>
                                    <input type="radio" name="delivery_method" value="store_collection">
                                    Store Collection (FREE)
                                </label>
                            </div>
                        </div>
                        
                        <div class="form-section">
                            <h3>Billing Address</h3>
                            <div class="form-group">
                                <label for="billing_address">Address</label>
                                <textarea id="billing_address" name="billing_address" rows="3" required><?php echo htmlspecialchars($user['address']); ?></textarea>
                            </div>
                        </div>
                        
                        <div class="form-section">
                            <h3>Delivery Address</h3>
                            <div class="form-group">
                                <label>
                                    <input type="checkbox" id="same_as_billing" checked>
                                    Same as billing address
                                </label>
                            </div>
                            <div class="form-group" id="delivery_address_group" style="display: none;">
                                <label for="delivery_address">Delivery Address</label>
                                <textarea id="delivery_address" name="delivery_address" rows="3"></textarea>
                            </div>
                        </div>
                        
                        <div class="form-section">
                            <h3>Payment Method</h3>
                            <div class="radio-group">
                                <label>
                                    <input type="radio" name="payment_method" value="card" checked>
                                    Credit/Debit Card
                                </label>
                                <label>
                                    <input type="radio" name="payment_method" value="paypal">
                                    PayPal
                                </label>
                                <label>
                                    <input type="radio" name="payment_method" value="bank_transfer">
                                    Bank Transfer
                                </label>
                            </div>
                        </div>
                        
                        <div class="form-section">
                            <h3>Special Instructions</h3>
                            <div class="form-group">
                                <textarea name="special_instructions" rows="3" placeholder="Any special delivery instructions..."></textarea>
                            </div>
                        </div>
                        
                        <button type="submit" class="btn btn-primary btn-large">Place Order</button>
                    </form>
                </div>
                
                <div class="order-summary">
                    <div class="summary-card">
                        <h3>Order Summary</h3>
                        
                        <div class="order-items">
                            <?php foreach ($cart_items as $item): ?>
                            <div class="summary-item">
                                <div class="item-info">
                                    <h4><?php echo htmlspecialchars($item['product']['name']); ?></h4>
                                    <p>Qty: <?php echo $item['quantity']; ?> × £<?php echo number_format($item['product']['price'], 2); ?></p>
                                </div>
                                <div class="item-total">
                                    £<?php echo number_format($item['subtotal'], 2); ?>
                                </div>
                            </div>
                            <?php endforeach; ?>
                        </div>
                        
                        <div class="summary-totals">
                            <div class="summary-row">
                                <span>Subtotal:</span>
                                <span>£<?php echo number_format($total_amount, 2); ?></span>
                            </div>
                            
                            <div class="summary-row" id="shipping_row">
                                <span>Shipping:</span>
                                <span id="shipping_cost">£<?php echo number_format($shipping_cost, 2); ?></span>
                            </div>
                            
                            <div class="summary-row total">
                                <span>Total:</span>
                                <span id="final_total">£<?php echo number_format($final_total, 2); ?></span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>

    <script src="js/main.js"></script>
    <script>
        document.getElementById('same_as_billing').addEventListener('change', function() {
            const deliveryGroup = document.getElementById('delivery_address_group');
            const deliveryTextarea = document.getElementById('delivery_address');
            const billingTextarea = document.getElementById('billing_address');
            
            if (this.checked) {
                deliveryGroup.style.display = 'none';
                deliveryTextarea.value = billingTextarea.value;
            } else {
                deliveryGroup.style.display = 'block';
                deliveryTextarea.value = '';
            }
        });
        
        document.querySelectorAll('input[name="delivery_method"]').forEach(function(radio) {
            radio.addEventListener('change', function() {
                const shippingCost = document.getElementById('shipping_cost');
                const finalTotal = document.getElementById('final_total');
                const subtotal = <?php echo $total_amount; ?>;
                
                if (this.value === 'store_collection') {
                    shippingCost.textContent = 'FREE';
                    finalTotal.textContent = '£' + subtotal.toFixed(2);
                } else {
                    shippingCost.textContent = '£<?php echo number_format($shipping_cost, 2); ?>';
                    finalTotal.textContent = '£<?php echo number_format($final_total, 2); ?>';
                }
            });
        });
    </script>
</body>
</html>